import tkinter as tk
from tkinter import *
import random
from tkinter import *
import random
from tkinter import Label
import tkinter.messagebox


class WindowOne(tk.Tk):
    def __init__(self):
        super().__init__()
        self.geometry("350x230")
        self.img = tk.PhotoImage(file='filet.png')
        self.configure(bg='brown')
        self.img_label = tk.Label(self, image=self.img)
        self.img_label.place(x=2, y=2, relheight=1, relwidth=1)
        self.label_entry = tkinter.Label(self, 
                                         text='The Steak Joint',
                                         fg='orange',
                                         bg='red')
        self.label_entry.place(x=130, y=30)
        self.update()
        tables = ['Dinner 1 ', 'Dinner 2 ', 'Dinner 3 ', 'Dinner 4 ', 'Dinner 5 ']
        price = [35.52, 27.13, 41.71, 39.95, 48.20]
        dinner = ['Dinner 1 ', 'Dinner 2 ', 'Dinner 3 ', 'Dinner 4 ', 'Dinner 5 ']
        print(random.choice(dinner))
        price = [35.52, 27.13, 41.71, 39.95, 48.20]
        print(random.choice(price))
        self.update()
        b1 = Button(self, text='Is this your dinner for the reservation? (Yes)', 
                                        bg = 'pink',
                                        fg = 'purple',
                                        command = window_two)
        b1.pack(side= TOP)
        b2 = Button(self, text='No', 
                                        bg = 'pink',
                                        fg = 'purple',
                                        command = self.destroy)
        b2.pack(side=LEFT)
        def stop():
            window_one.destroy()
        b3 = Button(self, text='Close', 
                                bg = 'pink',
                                fg = 'purple',
                                command = self.destroy)
        b3.pack(side=BOTTOM)
        def exit():
            window_one.destroy()

class window_two(tk.Toplevel):
    def __init__(self):
        super().__init__()
        self.title('Your guessed bill')
        def message():
            window_two = Toplevel()
            total_price = Label(text='The total price is: $')
            self.geometry("350x570")
            self.configure(bg='orange')
            self.img = tkinter.PhotoImage(file='steakwithfries.jpg')
            self.img_label = tkinter.Label(self, image=self.img)
            self.img_label.place(x=2, y=2, relheight=1, relwidth=1)
            self.label_entry = tkinter.Label(self, 
                                         text='You will now have a great dinner with your people that you invited!',
                                         fg='blue',
                                         bg='orange')
            self.label_entry.place(x=130, y=30)
            Label.pack()
            self.update()
            b4 = Button(self, text='Close',
                                    bg = 'pink',
                                    fg = 'purple',
                                    command = self.destroy)
            b4.pack(side=BOTTOM)
            def exit():
                window_two.destroy()
            self.update()
    def open_Toplevel():
        pass

window_one: WindowOne = WindowOne()
window_one.mainloop()
window_two.open_Toplevel()